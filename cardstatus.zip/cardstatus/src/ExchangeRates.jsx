function ExchangeRates() {
    return (
      <div className="container mt-4 animate__animated animate__fadeIn">
        <h3>Exchange Rate History</h3>
        <p>1 USD = 85.43 INR</p>
        <p>1 EUR = 97.33 INR</p>
        <p>1 GBP = 113.48 INR</p>
        <p>1 AUD = 54.47 INR</p>
        <p>1 CAD = 61.69 INR</p>
        <p>1 SGD = 65.15 INR</p>
        <p>1 CHF = 104.63 INR</p>
        <p>1 JPY = 0.60 INR</p>
        <p>1 CNY = 11.70 INR</p>

      </div>
    );
  }

  export default ExchangeRates;