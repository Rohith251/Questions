import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Card, Button, Modal, Form, Nav, Navbar, Container } from 'react-bootstrap';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import './CardDesign.css';

function Dashboard() {
  const [profilePic, setProfilePic] = useState(null);
  const [showLimitModal, setShowLimitModal] = useState(false);
  const [cardStatus, setCardStatus] = useState('Active');
  const [isFlipped, setIsFlipped] = useState(false);

  const handleProfilePicUpload = (e) => {
    const file = e.target.files[0];
    if (file) setProfilePic(URL.createObjectURL(file));
  };

  const handleBlockCard = () => {
    setCardStatus('Blocked');
  };

  return (
    <div className="container mt-4 animate__animated animate__fadeIn">
      {/* Header */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Welcome back, Rohith 👋</h2>
        <div className="d-flex align-items-center">
          <i className="bi bi-bell fs-4 me-3"></i>
          <div>
            <label htmlFor="profileUpload" style={{ cursor: 'pointer' }}>
              {profilePic ? (
                <img
                  src={profilePic}
                  alt="Profile"
                  className="rounded-circle"
                  width="50"
                  height="50"
                />
              ) : (
                <div className="rounded-circle bg-secondary text-white d-flex justify-content-center align-items-center" style={{ width: 50, height: 50 }}>
                  Upload
                </div>
              )}
            </label>
            <input
              type="file"
              id="profileUpload"
              className="d-none"
              accept="image/*"
              onChange={handleProfilePicUpload}
            />
          </div>
        </div>
      </div>

      {/* Layout Split - Card Left, Info Right */}
      <div className="row">
        {/* Actions and Info */}
        <div className="col-md-6">
          <Card className="mb-4 shadow-sm">
            <Card.Body>
              <Card.Title>Card Information</Card.Title>
              <p>Status: <span className={cardStatus === 'Active' ? 'text-success' : 'text-danger'}>{cardStatus}</span></p>
              <p>Card Type: Primary</p>
              <p>Issuing Bank: Sundaram Bank</p>
              <p>CVV: ***</p>
            </Card.Body>
          </Card>

          <Card className="mb-4 shadow-sm">
            <Card.Body>
              <Card.Title>Actions</Card.Title>
              <div className="d-flex flex-wrap gap-3">
                <Button variant="primary">Reload Card</Button>
                <Button variant="danger" onClick={handleBlockCard}>Block Card</Button>
                <Button variant="secondary" onClick={() => setShowLimitModal(true)}>Set Transaction Limits</Button>
                <Button variant="warning">Change PIN</Button>
                <Button variant="info">Request Statement</Button>
              </div>
            </Card.Body>
          </Card>
        </div>

        {/* Styled Card on Right */}
        <div className="col-md-6 d-flex justify-content-center">
          <div
            className={`styled-forex-card-container ${isFlipped ? 'flipped' : ''}`}
            onMouseEnter={() => setIsFlipped(true)}
            onMouseLeave={() => setIsFlipped(false)}
          >
            <div className="styled-forex-card front">
              <div className="card-chip"></div>
              <div className="card-logo">🌐</div>
              <div className="card-number">1234 5678 9012 3456</div>
              <div className="card-name">Rohith</div>
              <div className="card-expiry">12/25</div>
              <div className="card-bank">SUNDARAM FOREX CARD</div>
            </div>
            <div className="styled-forex-card back">
              <div className="cvv-box">CVV: 123</div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal for Transaction Limit */}
      <Modal show={showLimitModal} onHide={() => setShowLimitModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Set Transaction Limits</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Daily Limit ($)</Form.Label>
              <Form.Control type="number" placeholder="Enter amount" />
            </Form.Group>
            <Button variant="primary" onClick={() => setShowLimitModal(false)}>
              Save Changes
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
    </div>
  );
}
export default Dashboard;